const boardEl = document.getElementById('board');
const turnIndicator = document.getElementById('turn-indicator');
const resetBtn = document.getElementById('reset-btn');
const playAgainBtn = document.getElementById('play-again-btn');
const victoryOverlay = document.getElementById('victory-overlay');
const victoryTitle = document.getElementById('victory-title');
const victoryStats = document.getElementById('victory-stats');

const tForced = document.getElementById('toggle-forced');
const tChain = document.getElementById('toggle-chain');
const tLongest = document.getElementById('toggle-longest');
const tRepetition = document.getElementById('toggle-repetition');
const tWhiteFirst = document.getElementById('toggle-white-first');

let board = [];
let turn = 'black';
let selected = null;
let validMoves = [];
let chainPiece = null;
let moveCount = 0;
let positionHistory = {};

const CROWN_SVG = `
  <svg class="crown-svg" viewBox="0 0 24 24" fill="#fbbf24" stroke="#b45309" stroke-width="1.5">
    <path d="M2 18h20l-2-11-5 4-3-6-3 6-5-4-2 11zm2 2h16v2H4v-2z"/>
  </svg>
`;

function initGame() {
  board = Array(8).fill(null).map(() => Array(8).fill(null));
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if ((r + c) % 2 === 1) {
        if (r < 3) board[r][c] = { color: 'white', king: false };
        if (r > 4) board[r][c] = { color: 'black', king: false };
      }
    }
  }
  turn = tWhiteFirst.checked ? 'white' : 'black';
  selected = null;
  validMoves = [];
  chainPiece = null;
  moveCount = 0;
  positionHistory = {};
  recordPosition();
  victoryOverlay.classList.add('hidden');
  updateTurnUI();
  renderBoard();
}

function updateTurnUI() {
  turnIndicator.textContent = turn === 'black' ? "Black's Turn" : "White's Turn";
  turnIndicator.className = `turn-badge ${turn}-turn`;
}

function getDirections(piece) {
  if (piece.king) return [[-1, -1], [-1, 1], [1, -1], [1, 1]];
  return piece.color === 'black' ? [[-1, -1], [-1, 1]] : [[1, -1], [1, 1]];
}

function getJumpSequences(r, c, piece, currentBoard) {
  let sequences = [];
  const dirs = getDirections(piece);

  for (const [dr, dc] of dirs) {
    const midR = r + dr, midC = c + dc;
    const endR = r + dr * 2, endC = c + dc * 2;

    if (endR >= 0 && endR < 8 && endC >= 0 && endC < 8) {
      const midPiece = currentBoard[midR][midC];
      if (midPiece && midPiece.color !== piece.color && !currentBoard[endR][endC]) {
        const nextBoard = currentBoard.map(row => row.map(cell => cell ? { ...cell } : null));
        nextBoard[endR][endC] = { ...piece };
        nextBoard[r][c] = null;
        nextBoard[midR][midC] = null;

        const promoted = (!piece.king && ((piece.color === 'black' && endR === 0) || (piece.color === 'white' && endR === 7)));
        const step = { toR: endR, toC: endC, capR: midR, capC: midC };

        if (tChain.checked && !promoted) {
          const subSeqs = getJumpSequences(endR, endC, nextBoard[endR][endC], nextBoard);
          if (subSeqs.length > 0) {
            for (const sub of subSeqs) sequences.push([step, ...sub]);
          } else {
            sequences.push([step]);
          }
        } else {
          sequences.push([step]);
        }
      }
    }
  }
  return sequences;
}

function getAllLegalMoves(playerColor) {
  let allMoves = [];
  let maxJumpLen = 0;

  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      if (chainPiece && (chainPiece.r !== r || chainPiece.c !== c)) continue;
      const piece = board[r][c];
      if (!piece || piece.color !== playerColor) continue;

      const seqs = getJumpSequences(r, c, piece, board);
      for (const seq of seqs) {
        if (seq.length > maxJumpLen) maxJumpLen = seq.length;
        allMoves.push({
          fromR: r, fromC: c,
          toR: seq[0].toR, toC: seq[0].toC,
          capR: seq[0].capR, capC: seq[0].capC,
          isJump: true,
          chainLen: seq.length
        });
      }

      if (!chainPiece) {
        for (const [dr, dc] of getDirections(piece)) {
          const nr = r + dr, nc = c + dc;
          if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && !board[nr][nc]) {
            allMoves.push({ fromR: r, fromC: c, toR: nr, toC: nc, isJump: false, chainLen: 0 });
          }
        }
      }
    }
  }

  const hasJumps = maxJumpLen > 0;
  if ((tForced.checked || tLongest.checked || chainPiece) && hasJumps) {
    allMoves = allMoves.filter(m => m.isJump);
    if (tLongest.checked) {
      allMoves = allMoves.filter(m => m.chainLen === maxJumpLen);
    }
  }

  return allMoves;
}

function handleSquareClick(r, c) {
  const move = validMoves.find(m => m.toR === r && m.toC === c);
  if (move) {
    executeMove(move);
    return;
  }

  if (chainPiece) return;

  const piece = board[r][c];
  if (piece && piece.color === turn) {
    const legal = getAllLegalMoves(turn);
    const pieceMoves = legal.filter(m => m.fromR === r && m.fromC === c);
    selected = { r, c };
    validMoves = pieceMoves;
    renderBoard();
  } else {
    selected = null;
    validMoves = [];
    renderBoard();
  }
}

function executeMove(move) {
  const piece = board[move.fromR][move.fromC];
  board[move.toR][move.toC] = piece;
  board[move.fromR][move.fromC] = null;
  moveCount++;

  if (move.isJump) {
    board[move.capR][move.capC] = null;
  }

  let promoted = false;
  if (!piece.king) {
    if ((piece.color === 'black' && move.toR === 0) || (piece.color === 'white' && move.toR === 7)) {
      piece.king = true;
      promoted = true;
    }
  }

  if (move.isJump && tChain.checked && !promoted) {
    const moreJumps = getJumpSequences(move.toR, move.toC, piece, board);
    if (moreJumps.length > 0) {
      chainPiece = { r: move.toR, c: move.toC };
      selected = { r: move.toR, c: move.toC };
      validMoves = getAllLegalMoves(turn);
      renderBoard();
      return;
    }
  }

  chainPiece = null;
  selected = null;
  validMoves = [];
  turn = turn === 'black' ? 'white' : 'black';
  updateTurnUI();
  renderBoard();

  if (tRepetition.checked && recordPosition() >= 3) {
    triggerEnd("DRAW!", `Threefold repetition reached in ${moveCount} moves.`);
    return;
  }

  const nextMoves = getAllLegalMoves(turn);
  if (nextMoves.length === 0) {
    const winner = turn === 'black' ? 'WHITE' : 'BLACK';
    triggerEnd(`${winner} WINS!`, `Victory achieved in ${moveCount} total moves!`);
  }
}

function recordPosition() {
  const key = turn + ':' + board.map(r => r.map(c => c ? (c.color[0] + (c.king ? 'K' : 'M')) : '.').join('')).join('/');
  positionHistory[key] = (positionHistory[key] || 0) + 1;
  return positionHistory[key];
}

function triggerEnd(title, stats) {
  victoryTitle.textContent = title;
  victoryStats.textContent = stats;
  victoryOverlay.classList.remove('hidden');
  launchConfetti();
}

function renderBoard() {
  boardEl.innerHTML = '';
  for (let r = 0; r < 8; r++) {
    for (let c = 0; c < 8; c++) {
      const sq = document.createElement('div');
      sq.className = `square ${(r + c) % 2 === 0 ? 'light' : 'dark'}`;
      if (validMoves.some(m => m.toR === r && m.toC === c)) {
        sq.classList.add('valid-move');
      }
      sq.addEventListener('click', () => handleSquareClick(r, c));

      const piece = board[r][c];
      if (piece) {
        const pEl = document.createElement('div');
        pEl.className = `piece ${piece.color}`;
        if (selected && selected.r === r && selected.c === c) {
          pEl.classList.add('selected');
        }
        if (piece.king) {
          pEl.innerHTML = CROWN_SVG;
        }
        sq.appendChild(pEl);
      }
      boardEl.appendChild(sq);
    }
  }
}

function launchConfetti() {
  const canvas = document.getElementById('confetti-canvas');
  const ctx = canvas.getContext('2d');
  canvas.width = 416;
  canvas.height = 416;
  const colors = ['#fbbf24', '#34d399', '#60a5fa', '#f87171', '#a78bfa'];
  const particles = Array.from({ length: 75 }, () => ({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height - canvas.height,
    r: Math.random() * 5 + 3,
    d: Math.random() * 3 + 2,
    color: colors[Math.floor(Math.random() * colors.length)]
  }));

  let frame = 0;
  function animate() {
    if (victoryOverlay.classList.contains('hidden') || frame > 180) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => {
      p.y += p.d;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
      if (p.y > canvas.height) p.y = -10;
    });
    frame++;
    requestAnimationFrame(animate);
  }
  animate();
}

tWhiteFirst.addEventListener('change', () => {
  if (moveCount === 0) initGame();
});

[tForced, tChain, tLongest].forEach(toggle => {
  toggle.addEventListener('change', () => {
    if (selected) {
      validMoves = getAllLegalMoves(turn).filter(m => m.fromR === selected.r && m.fromC === selected.c);
      renderBoard();
    }
  });
});

resetBtn.addEventListener('click', initGame);
playAgainBtn.addEventListener('click', initGame);

initGame();
